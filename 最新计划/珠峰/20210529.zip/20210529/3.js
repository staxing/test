/*
 * 数据通信机制：ajax/axios/fetch实操及优化 
 *   + ajax、axios、fetch三者的区别
 *   + axios二次封装
 *   + 课后思考：fetch的二次封装处理
 * http://www.axios-js.com/zh-cn/docs/
 * https://developer.mozilla.org/zh-CN/docs/Web/API/Fetch_API/Using_Fetch
 */